import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import joblib
import os

def load_data(file_path):
    """Load the cleaned dataset."""
    return pd.read_csv(file_path)

def prepare_data(df):
    """Prepare features and target."""
    # Drop customerID if present
    if 'customerID' in df.columns:
        df = df.drop('customerID', axis=1)

    # Separate features and target
    X = df.drop('Churn', axis=1)
    y = df['Churn']

    return X, y

def train_models(X_train, y_train):
    """Train Logistic Regression and Random Forest models."""
    # Logistic Regression
    lr_model = LogisticRegression(random_state=42, max_iter=1000)
    lr_model.fit(X_train, y_train)

    # Random Forest
    rf_model = RandomForestClassifier(random_state=42, n_estimators=100)
    rf_model.fit(X_train, y_train)

    return lr_model, rf_model

def evaluate_model(model, X_test, y_test, model_name):
    """Evaluate the model and print metrics."""
    y_pred = model.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    conf_matrix = confusion_matrix(y_test, y_pred)

    print(f"\n{model_name} Evaluation:")
    print(f"Accuracy: {accuracy:.4f}")
    print(f"Precision: {precision:.4f}")
    print(f"Recall: {recall:.4f}")
    print(f"F1 Score: {f1:.4f}")
    print(f"Confusion Matrix:\n{conf_matrix}")

    return accuracy, precision, recall, f1

def save_model(model, file_path):
    """Save the trained model."""
    joblib.dump(model, file_path)
    print(f"Model saved to {file_path}")

def main():
    """Main training function."""
    # Load data
    data_path = os.path.join('..', 'data', 'cleaned_data.csv')
    df = load_data(data_path)

    # Prepare data
    X, y = prepare_data(df)

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train models
    lr_model, rf_model = train_models(X_train, y_train)

    # Evaluate models
    lr_metrics = evaluate_model(lr_model, X_test, y_test, "Logistic Regression")
    rf_metrics = evaluate_model(rf_model, X_test, y_test, "Random Forest")

    # Choose best model (based on F1 score)
    if rf_metrics[3] > lr_metrics[3]:
        best_model = rf_model
        model_name = "Random Forest"
    else:
        best_model = lr_model
        model_name = "Logistic Regression"

    print(f"\nBest model: {model_name}")

    # Save best model
    model_path = os.path.join('..', 'models', 'churn_model.pkl')
    save_model(best_model, model_path)

if __name__ == "__main__":
    main()