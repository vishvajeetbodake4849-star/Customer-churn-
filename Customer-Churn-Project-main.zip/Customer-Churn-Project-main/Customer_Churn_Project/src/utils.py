import pandas as pd
import joblib
import os
from sklearn.ensemble import RandomForestClassifier

def load_model(model_path):
    """Load the trained model."""
    return joblib.load(model_path)

def load_data(data_path):
    """Load the cleaned dataset."""
    return pd.read_csv(data_path)

def get_feature_importance(model, feature_names):
    """Get feature importance from Random Forest model."""
    if isinstance(model, RandomForestClassifier):
        importance = model.feature_importances_
        return pd.DataFrame({'feature': feature_names, 'importance': importance}).sort_values('importance', ascending=False)
    else:
        return None

def calculate_kpis(df):
    """Calculate key performance indicators."""
    total_customers = len(df)
    active_customers = len(df[df['Churn'] == 0])
    churned_customers = len(df[df['Churn'] == 1])
    churn_rate = 0.0
    avg_monthly_charges = 0.0

    if total_customers > 0:
        churn_rate = (churned_customers / total_customers) * 100
        avg_monthly_charges = df['MonthlyCharges'].mean()

    return {
        'total_customers': total_customers,
        'active_customers': active_customers,
        'churned_customers': churned_customers,
        'churn_rate': churn_rate,
        'avg_monthly_charges': avg_monthly_charges
    }

def preprocess_input_data(input_data, original_df):
    """Preprocess user input data for prediction."""
    # Create a DataFrame from input
    input_df = pd.DataFrame([input_data])

    # Apply same preprocessing as training data
    # Label encode binary variables
    binary_mappings = {
        'gender': {'Male': 1, 'Female': 0},
        'SeniorCitizen': {'Yes': 1, 'No': 0},
        'Partner': {'Yes': 1, 'No': 0},
        'Dependents': {'Yes': 1, 'No': 0},
        'PhoneService': {'Yes': 1, 'No': 0},
        'MultipleLines': {'Yes': 1, 'No': 0, 'No phone service': 0},
        'OnlineSecurity': {'Yes': 1, 'No': 0, 'No internet service': 0},
        'OnlineBackup': {'Yes': 1, 'No': 0, 'No internet service': 0},
        'DeviceProtection': {'Yes': 1, 'No': 0, 'No internet service': 0},
        'TechSupport': {'Yes': 1, 'No': 0, 'No internet service': 0},
        'StreamingTV': {'Yes': 1, 'No': 0, 'No internet service': 0},
        'StreamingMovies': {'Yes': 1, 'No': 0, 'No internet service': 0},
        'PaperlessBilling': {'Yes': 1, 'No': 0}
    }

    for col, mapping in binary_mappings.items():
        if col in input_df.columns:
            input_df[col] = input_df[col].map(mapping)

    # One-hot encode categorical variables
    categorical_cols = ['Contract', 'PaymentMethod', 'InternetService']
    input_df = pd.get_dummies(input_df, columns=categorical_cols, drop_first=True)

    # Ensure all columns from training data are present
    for col in original_df.columns:
        if col not in input_df.columns and col != 'Churn' and col != 'customerID':
            input_df[col] = 0

    # Reorder columns to match training data
    feature_cols = [col for col in original_df.columns if col not in ['Churn', 'customerID']]
    input_df = input_df[feature_cols]

    return input_df