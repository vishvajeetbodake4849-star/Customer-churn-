import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer
import os

def load_data(file_path):
    """Load the customer churn dataset."""
    return pd.read_csv(file_path)

def handle_missing_values(df):
    """Handle missing values in the dataset."""
    # Convert TotalCharges to numeric, handle empty strings
    df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce')

    # Fill missing TotalCharges with median
    df['TotalCharges'].fillna(df['TotalCharges'].median(), inplace=True)

    # Fill any other missing values if present
    df.fillna(df.mode().iloc[0], inplace=True)

    return df

def encode_categorical_variables(df):
    """Encode categorical variables."""
    # Label encode binary variables (Yes/No, Male/Female, etc.)
    label_encoder = LabelEncoder()
    binary_cols = ['gender', 'Partner', 'Dependents', 'PhoneService', 'PaperlessBilling', 'Churn',
                   'OnlineSecurity', 'OnlineBackup', 'DeviceProtection', 'TechSupport',
                   'StreamingTV', 'StreamingMovies', 'MultipleLines']

    for col in binary_cols:
        if col in df.columns:
            # Handle special cases
            if col == 'gender':
                df[col] = df[col].map({'Male': 1, 'Female': 0})
            elif col == 'MultipleLines':
                df[col] = df[col].map({'Yes': 1, 'No': 0, 'No phone service': 0})
            else:
                df[col] = df[col].map({'Yes': 1, 'No': 0, 'No internet service': 0})

    # One-hot encode multi-class variables
    categorical_cols = ['Contract', 'PaymentMethod', 'InternetService']
    df = pd.get_dummies(df, columns=categorical_cols, drop_first=True)

    return df

def remove_duplicates(df):
    """Remove duplicate rows."""
    return df.drop_duplicates()

def preprocess_data(input_file, output_file):
    """Main preprocessing function."""
    # Load data
    df = load_data(input_file)

    # Handle missing values
    df = handle_missing_values(df)

    # Encode categorical variables
    df = encode_categorical_variables(df)

    # Remove duplicates
    df = remove_duplicates(df)

    # Save cleaned data
    df.to_csv(output_file, index=False)
    print(f"Cleaned data saved to {output_file}")
    print(f"Dataset shape: {df.shape}")

    return df

if __name__ == "__main__":
    input_file = os.path.join('..', 'data', 'customer_churn.csv')
    output_file = os.path.join('..', 'data', 'cleaned_data.csv')
    preprocess_data(input_file, output_file)