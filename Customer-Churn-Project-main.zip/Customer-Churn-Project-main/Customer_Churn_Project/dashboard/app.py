import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
import sys
import os
from sklearn.model_selection import train_test_split
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import joblib

# Ensure we can import src from the project root when Streamlit runs from any cwd
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if BASE_DIR not in sys.path:
    sys.path.append(BASE_DIR)

from src.utils import load_model, load_data, get_feature_importance, calculate_kpis, preprocess_input_data

# Page configuration
st.set_page_config(
    page_title="Customer Churn Analytics Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for colorful theme
st.markdown("""
<style>
    .main {
        background-color: #f0f2f6;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 2px;
    }
    .stTabs [data-baseweb="tab"] {
        height: 50px;
        white-space: pre-wrap;
        background-color: #ffffff;
        border-radius: 4px 4px 0 0;
        gap: 1px;
        padding-top: 10px;
        padding-bottom: 10px;
    }
    .stTabs [aria-selected="true"] {
        background-color: #4ECDC4;
        color: white;
    }
    .metric-card {
        background-color: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        margin: 10px;
    }
</style>
""", unsafe_allow_html=True)

# Load data and model
@st.cache_data
def load_app_data():
    # Use absolute paths so it works no matter where streamlit run is invoked
    data_path = os.path.join(BASE_DIR, 'data', 'cleaned_data.csv')
    model_path = os.path.join(BASE_DIR, 'models', 'churn_model.pkl')
    df = load_data(data_path)
    model = load_model(model_path)
    return df, model

df, model = load_app_data()

# Sidebar filters
st.sidebar.title("🔍 Filters")

# Gender filter
gender_options = ['All'] + list(df['gender'].unique())
selected_gender = st.sidebar.selectbox("Gender", gender_options)

# Contract filter
contract_options = ['All'] + [col.replace('Contract_', '') for col in df.columns if col.startswith('Contract_')]
selected_contract = st.sidebar.selectbox("Contract Type", contract_options)

# Payment Method filter
payment_options = ['All'] + [col.replace('PaymentMethod_', '') for col in df.columns if col.startswith('PaymentMethod_')]
selected_payment = st.sidebar.selectbox("Payment Method", payment_options)

# Tenure range
min_tenure, max_tenure = int(df['tenure'].min()), int(df['tenure'].max())
tenure_range = st.sidebar.slider("Tenure Range", min_tenure, max_tenure, (min_tenure, max_tenure))

# Apply filters
filtered_df = df.copy()
if selected_gender != 'All':
    filtered_df = filtered_df[filtered_df['gender'] == (1 if selected_gender == 'Male' else 0)]

if selected_contract != 'All':
    contract_col = f'Contract_{selected_contract}'
    if contract_col in filtered_df.columns:
        filtered_df = filtered_df[filtered_df[contract_col] == 1]

if selected_payment != 'All':
    payment_col = f'PaymentMethod_{selected_payment}'
    if payment_col in filtered_df.columns:
        filtered_df = filtered_df[filtered_df[payment_col] == 1]

filtered_df = filtered_df[(filtered_df['tenure'] >= tenure_range[0]) & (filtered_df['tenure'] <= tenure_range[1])]

# Main content
st.title("📊 Customer Churn Prediction & Analytics Dashboard")

# Tabs
tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(["📈 Dashboard", "🤖 Model Prediction", "💡 Insights", "📊 Sales Analysis", "👥 Customer Segmentation", "🔧 Data & Models"])

with tab1:
    # KPI Cards
    st.header("Key Performance Indicators")

    if filtered_df.empty:
        st.warning("No records match the selected filters. Adjust the filters to see KPI metrics and visualizations.")
        kpis = {'total_customers': 0, 'active_customers': 0, 'churned_customers': 0, 'churn_rate': 0.0, 'avg_monthly_charges': 0.0}
    else:
        kpis = calculate_kpis(filtered_df)

    col1, col2, col3, col4, col5 = st.columns(5)

    with col1:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.metric("Total Customers", f"{kpis['total_customers']:,}")
        st.markdown('</div>', unsafe_allow_html=True)

    with col2:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.metric("Active Customers", f"{kpis['active_customers']:,}")
        st.markdown('</div>', unsafe_allow_html=True)

    with col3:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.metric("Churned Customers", f"{kpis['churned_customers']:,}")
        st.markdown('</div>', unsafe_allow_html=True)

    with col4:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.metric("Churn Rate", f"{kpis['churn_rate']:.1f}%")
        st.markdown('</div>', unsafe_allow_html=True)

    with col5:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.metric("Avg Monthly Charges", f"${kpis['avg_monthly_charges']:.2f}")
        st.markdown('</div>', unsafe_allow_html=True)

    # Charts
    st.header("Interactive Visualizations")

    col1, col2 = st.columns(2)

    with col1:
        # Churn by Gender
        gender_churn = filtered_df.groupby('gender')['Churn'].mean().reset_index()
        gender_churn['gender'] = gender_churn['gender'].map({0: 'Female', 1: 'Male'})
        fig_gender = px.bar(gender_churn, x='gender', y='Churn', title="Churn Rate by Gender",
                           labels={'Churn': 'Churn Rate'},
                           color='gender',
                           color_discrete_map={'Female': '#FF6B9D', 'Male': '#4ECDC4'})
        fig_gender.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font_color='black'
        )
        st.plotly_chart(fig_gender, width='stretch')

        # Monthly Charges Distribution
        fig_charges = px.histogram(filtered_df, x='MonthlyCharges', color='Churn',
                                  title="Monthly Charges Distribution",
                                  labels={'Churn': 'Churn Status'},
                                  color_discrete_map={0: '#4ECDC4', 1: '#FF6B6B'},
                                  opacity=0.7)
        fig_charges.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font_color='black'
        )
        st.plotly_chart(fig_charges, width='stretch')

    with col2:
        # Churn by Contract (Pie Chart)
        contract_cols = [col for col in filtered_df.columns if col.startswith('Contract_')]
        contract_churn = {}
        for col in contract_cols:
            contract_name = col.replace('Contract_', '')
            churn_rate = filtered_df[filtered_df[col] == 1]['Churn'].mean()
            contract_churn[contract_name] = churn_rate

        fig_contract = px.pie(values=list(contract_churn.values()), names=list(contract_churn.keys()),
                             title="Churn Rate by Contract Type",
                             color_discrete_sequence=px.colors.qualitative.Pastel)
        fig_contract.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font_color='black'
        )
        st.plotly_chart(fig_contract, width='stretch')

        # Tenure vs Churn Scatter
        fig_scatter = px.scatter(filtered_df, x='tenure', y='MonthlyCharges', color='Churn',
                                title="Tenure vs Monthly Charges",
                                labels={'Churn': 'Churn Status'},
                                color_discrete_map={0: '#4ECDC4', 1: '#FF6B6B'})
        fig_scatter.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font_color='black'
        )
        st.plotly_chart(fig_scatter, width='stretch')

    # Payment Method Analysis
    st.subheader("Payment Method Analysis")
    payment_cols = [col for col in filtered_df.columns if col.startswith('PaymentMethod_')]
    payment_churn = {}
    for col in payment_cols:
        payment_name = col.replace('PaymentMethod_', '')
        churn_rate = filtered_df[filtered_df[col] == 1]['Churn'].mean()
        payment_churn[payment_name] = churn_rate

    fig_payment = px.bar(x=list(payment_churn.keys()), y=list(payment_churn.values()),
                        title="Churn Rate by Payment Method",
                        labels={'x': 'Payment Method', 'y': 'Churn Rate'},
                        color=list(payment_churn.values()),
                        color_continuous_scale='RdYlGn_r')
    fig_payment.update_layout(
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font_color='black'
    )
    st.plotly_chart(fig_payment, width='stretch')

    # Churn Trend Over Time (assuming tenure represents time)
    tenure_churn = filtered_df.groupby('tenure')['Churn'].mean().reset_index()
    fig_trend = px.line(tenure_churn, x='tenure', y='Churn', title="Churn Rate Trend by Tenure",
                       labels={'Churn': 'Churn Rate', 'tenure': 'Tenure (months)'},
                       color_discrete_sequence=['#FF6B6B'])
    fig_trend.update_layout(
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font_color='black'
    )
    st.plotly_chart(fig_trend, width='stretch')

    # Correlation Heatmap
    st.subheader("Feature Correlation Heatmap")
    numeric_cols = ['tenure', 'MonthlyCharges', 'TotalCharges']
    corr_matrix = filtered_df[numeric_cols + ['Churn']].corr()

    fig_heatmap = px.imshow(corr_matrix, text_auto=True, aspect="auto",
                           title="Correlation Heatmap",
                           color_continuous_scale='RdBu_r')
    fig_heatmap.update_layout(
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font_color='black'
    )
    st.plotly_chart(fig_heatmap, width='stretch')

    # Download button
    st.download_button(
        label="📥 Download Filtered Data as CSV",
        data=filtered_df.to_csv(index=False),
        file_name='filtered_customer_data.csv',
        mime='text/csv'
    )

with tab2:
    st.header("🤖 Churn Prediction")

    # Input form
    st.subheader("Enter Customer Information")

    col1, col2 = st.columns(2)

    with col1:
        gender = st.selectbox("Gender", ["Male", "Female"])
        senior_citizen = st.selectbox("Senior Citizen", ["Yes", "No"])
        partner = st.selectbox("Partner", ["Yes", "No"])
        dependents = st.selectbox("Dependents", ["Yes", "No"])
        tenure = st.slider("Tenure (months)", 0, 72, 12)
        phone_service = st.selectbox("Phone Service", ["Yes", "No"])
        multiple_lines = st.selectbox("Multiple Lines", ["Yes", "No", "No phone service"])
        monthly_charges = st.number_input("Monthly Charges", 0.0, 200.0, 50.0)

    with col2:
        internet_service = st.selectbox("Internet Service", ["DSL", "Fiber optic", "No"])
        online_security = st.selectbox("Online Security", ["Yes", "No", "No internet service"])
        online_backup = st.selectbox("Online Backup", ["Yes", "No", "No internet service"])
        device_protection = st.selectbox("Device Protection", ["Yes", "No", "No internet service"])
        tech_support = st.selectbox("Tech Support", ["Yes", "No", "No internet service"])
        streaming_tv = st.selectbox("Streaming TV", ["Yes", "No", "No internet service"])
        streaming_movies = st.selectbox("Streaming Movies", ["Yes", "No", "No internet service"])
        total_charges = st.number_input("Total Charges", 0.0, 10000.0, 500.0)
        contract = st.selectbox("Contract", ["Month-to-month", "One year", "Two year"])
        paperless_billing = st.selectbox("Paperless Billing", ["Yes", "No"])
        payment_method = st.selectbox("Payment Method", ["Electronic check", "Mailed check", "Bank transfer (automatic)", "Credit card (automatic)"])

    # Prediction
    if st.button("🔮 Predict Churn"):
        input_data = {
            'gender': gender,
            'SeniorCitizen': senior_citizen,
            'Partner': partner,
            'Dependents': dependents,
            'tenure': tenure,
            'PhoneService': phone_service,
            'MultipleLines': multiple_lines,
            'InternetService': internet_service,
            'OnlineSecurity': online_security,
            'OnlineBackup': online_backup,
            'DeviceProtection': device_protection,
            'TechSupport': tech_support,
            'StreamingTV': streaming_tv,
            'StreamingMovies': streaming_movies,
            'Contract': contract,
            'PaperlessBilling': paperless_billing,
            'PaymentMethod': payment_method,
            'MonthlyCharges': monthly_charges,
            'TotalCharges': total_charges
        }

        # Preprocess input
        processed_input = preprocess_input_data(input_data, df.drop('Churn', axis=1))

        # Make prediction
        prediction = model.predict(processed_input)[0]
        probability = model.predict_proba(processed_input)[0][1]

        # Display result
        st.subheader("Prediction Result")
        if prediction == 1:
            st.error(f"⚠️ This customer is likely to churn with {probability:.1%} probability.")
        else:
            st.success(f"✅ This customer is likely to stay with {(1-probability):.1%} probability.")

        # Confidence visualization
        fig_conf = go.Figure(go.Indicator(
            mode="gauge+number",
            value=probability * 100,
            title={'text': "Churn Probability"},
            gauge={'axis': {'range': [0, 100]},
                   'bar': {'color': "darkred"},
                   'steps': [
                       {'range': [0, 30], 'color': "lightgreen"},
                       {'range': [30, 70], 'color': "yellow"},
                       {'range': [70, 100], 'color': "red"}]}))
        st.plotly_chart(fig_conf)

with tab3:
    st.header("💡 Insights & Recommendations")

    # Feature Importance
    st.subheader("Feature Importance (Random Forest)")
    feature_names = [col for col in df.columns if col not in ['Churn', 'customerID']]
    feature_imp = get_feature_importance(model, feature_names)

    if feature_imp is not None:
        fig_imp = px.bar(feature_imp.head(10), x='importance', y='feature', orientation='h',
                        title="Top 10 Feature Importances",
                        color='importance',
                        color_continuous_scale='Viridis')
        fig_imp.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font_color='black'
        )
        st.plotly_chart(fig_imp, width='stretch')

    # Insights
    st.subheader("Key Insights")

    churn_rate = kpis['churn_rate']
    top_features = feature_imp.head(3)['feature'].tolist() if feature_imp is not None else []

    insights = [
        f"Current churn rate is {churn_rate:.1f}%, which is {'high' if churn_rate > 20 else 'moderate' if churn_rate > 10 else 'low'}.",
        f"Top factors influencing churn: {', '.join(top_features)}.",
        "Customers with month-to-month contracts are more likely to churn.",
        "Higher monthly charges correlate with increased churn probability.",
        "Longer tenure customers are less likely to churn."
    ]

    for insight in insights:
        st.write(f"• {insight}")

    # Recommendations
    st.subheader("Business Recommendations")

    recommendations = [
        "Offer incentives for customers to switch to longer-term contracts.",
        "Implement loyalty programs for long-tenure customers.",
        "Review pricing strategies for high-charge customers.",
        "Improve customer service for electronic check payment users.",
        "Target retention efforts on customers with high churn probability."
    ]

    for rec in recommendations:
        st.write(f"✅ {rec}")

with tab4:
    st.header("📊 Sales Trend Analysis")

    # Load transaction data if available
    transaction_path = os.path.join(BASE_DIR, 'data', 'transactions.csv')
    if os.path.exists(transaction_path):
        transactions_df = pd.read_csv(transaction_path)
        transactions_df['date'] = pd.to_datetime(transactions_df['date'])
        transactions_df['month'] = transactions_df['date'].dt.to_period('M')

        # Monthly Sales Trend
        st.subheader("Monthly Sales Trend")
        monthly_sales = transactions_df.groupby('month')['amount'].sum().reset_index()
        monthly_sales['month'] = monthly_sales['month'].astype(str)

        fig_sales = px.line(monthly_sales, x='month', y='amount',
                           title="Monthly Sales Trend",
                           labels={'amount': 'Total Sales ($)', 'month': 'Month'},
                           color_discrete_sequence=['#FF6B6B'])
        fig_sales.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font_color='white'
        )
        st.plotly_chart(fig_sales, width='stretch')

        col1, col2 = st.columns(2)

        with col1:
            # Quarterly Sales Growth
            st.subheader("Quarterly Sales Growth")
            transactions_df['quarter'] = transactions_df['date'].dt.to_period('Q')
            quarterly_sales = transactions_df.groupby('quarter')['amount'].sum().reset_index()
            quarterly_sales['quarter'] = quarterly_sales['quarter'].astype(str)

            fig_quarterly = px.bar(quarterly_sales, x='quarter', y='amount',
                                 title="Quarterly Sales",
                                 labels={'amount': 'Total Sales ($)', 'quarter': 'Quarter'},
                                 color='amount',
                                 color_continuous_scale='Viridis')
            fig_quarterly.update_layout(
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                font_color='white'
            )
            st.plotly_chart(fig_quarterly, width='stretch')

        with col2:
            # Top Performing Products
            st.subheader("Top Performing Products")
            product_sales = transactions_df.groupby('product_category')['amount'].sum().reset_index()

            fig_products = px.pie(product_sales, values='amount', names='product_category',
                                 title="Sales by Product Category",
                                 color_discrete_sequence=px.colors.qualitative.Set3)
            st.plotly_chart(fig_products, width='stretch')

        # Yearly Sales Growth
        st.subheader("Yearly Sales Growth")
        transactions_df['year'] = transactions_df['date'].dt.year
        yearly_sales = transactions_df.groupby('year')['amount'].sum().reset_index()

        fig_yearly = px.bar(yearly_sales, x='year', y='amount',
                           title="Yearly Sales Growth",
                           labels={'amount': 'Total Sales ($)', 'year': 'Year'},
                           color='amount',
                           color_continuous_scale='Blues')
        fig_yearly.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font_color='white'
        )
        st.plotly_chart(fig_yearly, width='stretch')
    else:
        # Fallback to customer data simulation
        st.info("Transaction data not found. Using customer data for sales simulation.")

        # Monthly Sales Trend (simulated from customer data)
        st.subheader("Monthly Sales Trend (Simulated)")
        monthly_sales = filtered_df.groupby('tenure')['MonthlyCharges'].sum().reset_index()
        monthly_sales['tenure'] = monthly_sales['tenure'].astype(str)

        fig_sales = px.line(monthly_sales, x='tenure', y='MonthlyCharges',
                           title="Monthly Sales Trend (by Tenure)",
                           labels={'MonthlyCharges': 'Total Monthly Charges ($)', 'tenure': 'Tenure (Months)'},
                           color_discrete_sequence=['#FF6B6B'])
        fig_sales.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font_color='white'
        )
        st.plotly_chart(fig_sales, width='stretch')

        col1, col2 = st.columns(2)

        with col1:
            # Quarterly Sales Growth (simulated)
            st.subheader("Quarterly Sales Growth")
            filtered_df['quarter'] = ((filtered_df['tenure'] - 1) // 3) + 1
            quarterly_sales = filtered_df.groupby('quarter')['MonthlyCharges'].sum().reset_index()

            fig_quarterly = px.bar(quarterly_sales, x='quarter', y='MonthlyCharges',
                                 title="Quarterly Sales",
                                 labels={'MonthlyCharges': 'Total Charges ($)', 'quarter': 'Quarter'},
                                 color='MonthlyCharges',
                                 color_continuous_scale='Viridis')
            fig_quarterly.update_layout(
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                font_color='white'
            )
            st.plotly_chart(fig_quarterly, width='stretch')

        with col2:
            # Service Performance (based on charges)
            st.subheader("Service Performance")
            service_charges = {}
            if 'InternetService_Fiber optic' in filtered_df.columns:
                service_charges['Fiber Optic'] = filtered_df[filtered_df['InternetService_Fiber optic'] == 1]['MonthlyCharges'].sum()
            if 'InternetService_DSL' in filtered_df.columns:
                service_charges['DSL'] = filtered_df[filtered_df['InternetService_DSL'] == 1]['MonthlyCharges'].sum()
            if 'PhoneService' in filtered_df.columns:
                service_charges['Phone Service'] = filtered_df[filtered_df['PhoneService'] == 1]['MonthlyCharges'].sum()

            if service_charges:
                fig_services = px.pie(values=list(service_charges.values()), names=list(service_charges.keys()),
                                     title="Revenue by Service Type",
                                     color_discrete_sequence=px.colors.qualitative.Set3)
                st.plotly_chart(fig_services, width='stretch')

    # Churn Impact on Revenue (always available)
    st.subheader("Churn Impact on Revenue")
    churn_impact = filtered_df.groupby('Churn')['MonthlyCharges'].sum().reset_index()
    churn_impact['Churn'] = churn_impact['Churn'].map({0: 'Retained', 1: 'Churned'})

    fig_impact = px.bar(churn_impact, x='Churn', y='MonthlyCharges',
                       title="Revenue Impact of Churn",
                       labels={'MonthlyCharges': 'Total Monthly Charges ($)'},
                       color='Churn',
                       color_discrete_map={'Retained': '#4ECDC4', 'Churned': '#FF6B6B'})
    fig_impact.update_layout(
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font_color='white'
    )
    st.plotly_chart(fig_impact, width='stretch')

with tab5:
    st.header("👥 Customer Segmentation")

    # Perform K-Means Clustering
    # Select features for clustering
    cluster_features = ['tenure', 'MonthlyCharges', 'TotalCharges']
    cluster_data = filtered_df[cluster_features].dropna()

    if len(cluster_data) < 2:
        st.warning("Not enough data to perform clustering. Please broaden your filters or include more customer records.")
    else:
        # Scale the data
        scaler = StandardScaler()
        scaled_data = scaler.fit_transform(cluster_data)

        # Determine optimal number of clusters (elbow method visualization)
        st.subheader("Optimal Number of Clusters (Elbow Method)")
        wcss = []
        max_k = min(10, len(scaled_data))
        for i in range(1, max_k + 1):
            kmeans = KMeans(n_clusters=i, init='k-means++', random_state=42)
            kmeans.fit(scaled_data)
            wcss.append(kmeans.inertia_)

        fig_elbow = px.line(x=range(1, max_k + 1), y=wcss, title="Elbow Method for Optimal K",
                           labels={'x': 'Number of Clusters', 'y': 'WCSS'},
                           color_discrete_sequence=['#45B7D1'])
        fig_elbow.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font_color='white'
        )
        st.plotly_chart(fig_elbow, width='stretch')

        # Perform clustering with a valid number of clusters
        max_clusters = min(8, len(cluster_data))
        default_clusters = min(4, max_clusters)
        n_clusters = st.slider("Number of Clusters", 2, max_clusters, default_clusters)

        kmeans = KMeans(n_clusters=n_clusters, init='k-means++', random_state=42)
        clusters = kmeans.fit_predict(scaled_data)

        cluster_data['Cluster'] = clusters

        # Visualize clusters
        st.subheader("Customer Segments")
        fig_clusters = px.scatter_3d(cluster_data, x='tenure', y='MonthlyCharges', z='TotalCharges',
                                    color='Cluster', title="Customer Segmentation (3D View)",
                                    color_continuous_scale='Rainbow')
        st.plotly_chart(fig_clusters, width='stretch')

        # Cluster profiles
        st.subheader("Cluster Profiles")
        cluster_profiles = cluster_data.groupby('Cluster').mean()
        st.dataframe(cluster_profiles.style.highlight_max(axis=0))

        # Cluster distribution
        cluster_dist = cluster_data['Cluster'].value_counts().reset_index()
        cluster_dist.columns = ['Cluster', 'Count']

        fig_dist = px.bar(cluster_dist, x='Cluster', y='Count',
                         title="Customer Distribution by Cluster",
                         color='Count',
                         color_continuous_scale='Blues')
        fig_dist.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font_color='white'
        )
        st.plotly_chart(fig_dist, width='stretch')

with tab6:
    st.header("🔧 Data Preprocessing & Model Training")

    # Data Preprocessing Section
    st.subheader("Data Preprocessing")

    # Upload data
    uploaded_file = st.file_uploader("Upload CSV file for preprocessing", type="csv")
    if uploaded_file is not None:
        raw_df = pd.read_csv(uploaded_file)
        st.write("Raw Data Preview:")
        st.dataframe(raw_df.head())

        # Preprocessing steps
        if st.button("Run Preprocessing"):
            from src.data_preprocessing import handle_missing_values, encode_categorical_variables, remove_duplicates

            # Handle missing values
            processed_df = handle_missing_values(raw_df.copy())
            st.write("After handling missing values:")
            st.dataframe(processed_df.head())

            # Encode categorical variables
            processed_df = encode_categorical_variables(processed_df)
            st.write("After encoding categorical variables:")
            st.dataframe(processed_df.head())

            # Remove duplicates
            processed_df = remove_duplicates(processed_df)
            st.write("After removing duplicates:")
            st.dataframe(processed_df.head())

            # Download processed data
            st.download_button(
                label="📥 Download Processed Data",
                data=processed_df.to_csv(index=False),
                file_name='processed_data.csv',
                mime='text/csv'
            )

    # Model Training Section
    st.subheader("Model Training")

    if st.button("Train Models"):
        from src.model_training import prepare_data, train_models
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

        # Prepare data
        X, y = prepare_data(df)

        # Split data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        # Train models
        lr_model, rf_model = train_models(X_train, y_train)

        # Evaluate Logistic Regression
        lr_pred = lr_model.predict(X_test)
        lr_accuracy = accuracy_score(y_test, lr_pred)
        lr_precision = precision_score(y_test, lr_pred)
        lr_recall = recall_score(y_test, lr_pred)
        lr_f1 = f1_score(y_test, lr_pred)

        st.write("**Logistic Regression Performance:**")
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Accuracy", f"{lr_accuracy:.4f}")
        col2.metric("Precision", f"{lr_precision:.4f}")
        col3.metric("Recall", f"{lr_recall:.4f}")
        col4.metric("F1 Score", f"{lr_f1:.4f}")

        # Evaluate Random Forest
        rf_pred = rf_model.predict(X_test)
        rf_accuracy = accuracy_score(y_test, rf_pred)
        rf_precision = precision_score(y_test, rf_pred)
        rf_recall = recall_score(y_test, rf_pred)
        rf_f1 = f1_score(y_test, rf_pred)

        st.write("**Random Forest Performance:**")
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Accuracy", f"{rf_accuracy:.4f}")
        col2.metric("Precision", f"{rf_precision:.4f}")
        col3.metric("Recall", f"{rf_recall:.4f}")
        col4.metric("F1 Score", f"{rf_f1:.4f}")

        # Save models
        joblib.dump(lr_model, os.path.join(BASE_DIR, 'models', 'lr_model.pkl'))
        joblib.dump(rf_model, os.path.join(BASE_DIR, 'models', 'rf_model.pkl'))

        st.success("Models trained and saved successfully!")

# Footer
st.markdown("---")
st.markdown("Built with ❤️ using Streamlit, Scikit-learn & Plotly")