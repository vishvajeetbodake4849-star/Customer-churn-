# Customer Churn Prediction and Sales Analytics Dashboard

## Overview
This project is a comprehensive machine learning and data visualization solution for predicting customer churn and analyzing sales data. It includes data preprocessing, model training, customer segmentation, and an interactive Streamlit dashboard for insights and predictions.

## Features
- **Data Acquisition & Preprocessing**: ETL operations, handle missing values, normalize data, encode categorical variables
- **Machine Learning Models**: Logistic Regression, Random Forest, Decision Trees, Gradient Boosting for churn prediction
- **Customer Segmentation**: K-Means clustering for customer grouping and anomaly detection
- **Sales Trend Analysis**: Monthly, quarterly, and yearly sales growth analysis, product performance insights
- **Interactive Dashboard**: Real-time visualizations with colorful charts, heatmaps, bar charts, and line graphs
- **Advanced Analytics**: Feature importance, correlation analysis, model confidence, and business insights

## Project Structure
```
Customer_Churn_Project/
│
├── data/
│   ├── customer_churn.csv
│   ├── cleaned_data.csv
│   ├── transactions.csv
│
├── models/
│   ├── churn_model.pkl
│   ├── lr_model.pkl
│   ├── rf_model.pkl
│
├── src/
│   ├── data_preprocessing.py
│   ├── model_training.py
│   ├── utils.py
│   ├── __init__.py
│
├── dashboard/
│   ├── app.py
│
├── requirements.txt
├── README.md
```

## Installation
1. Clone the repository
2. Install dependencies: `pip install -r requirements.txt`
3. Run data preprocessing: `python src/data_preprocessing.py`
4. Train the model: `python src/model_training.py`
5. Launch the dashboard: `streamlit run dashboard/app.py`

## Usage
- Access the dashboard at `http://localhost:8501`
- **Dashboard Tab**: View KPIs, interactive visualizations, and correlation heatmap
- **Model Prediction Tab**: Make real-time churn predictions with custom inputs
- **Insights Tab**: Feature importance and business recommendations
- **Sales Analysis Tab**: Track sales trends, quarterly growth, and product performance
- **Customer Segmentation Tab**: Explore customer clusters and profiles
- **Data & Models Tab**: Upload data for preprocessing and train new models

## Technologies Used
- **Data Processing**: Python, Pandas, NumPy, Scikit-learn
- **Machine Learning**: Logistic Regression, Random Forest, K-Means Clustering
- **Visualization**: Streamlit, Plotly, Seaborn
- **Time Series Analysis**: Statsmodels, Pandas
- **Deep Learning Ready**: TensorFlow, PyTorch (for future ANN/RNN implementations)
- Scikit-learn
- Streamlit
- Plotly
- Matplotlib, Seaborn

## Dataset
The project uses customer churn data with features like tenure, monthly charges, contract type, payment method, and churn status.